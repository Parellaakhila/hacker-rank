import numpy as np
shape= tuple(map(int,input().split()))
print(np.zeros(shape,int), np.ones(shape,int), sep='\n')
