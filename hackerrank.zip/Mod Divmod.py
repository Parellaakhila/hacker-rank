# Enter your code here. Read input from STDIN. Print output to STDOUT

A = int(input())
B = int(input())

print(A//B)
print(A%B)
print(divmod(A, B))
