# Enter your code here. Read input from STDIN. Print output to STDOUT
from __future__ import print_function
eval(input())
