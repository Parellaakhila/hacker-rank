if __name__ == '__main__':
    a = int(input())
    b = int(input())
    c=a+b
    print(c)
    c=a-b
    print(c)
    c=a*b
    print(c)
